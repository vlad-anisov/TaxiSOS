You can build the latest TDLib for Android using the scripts provided at https://github.com/tdlib/td/blob/master/example/android.
